library(testthat)
library(gintools)

test_check("gintools")
