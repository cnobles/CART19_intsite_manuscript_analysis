# spraphal
R-package for assistance with sparse graphical analysis.
