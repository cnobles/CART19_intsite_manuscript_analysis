library(testthat)
library(spraphal)

test_check("spraphal")
